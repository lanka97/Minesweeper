﻿using Minesweeper.Util.MinesPlacer;
using Minesweeper.Util.Prompts;

namespace Minesweeper;

public static class Program
{
    private static void Main()
    {
        ConsoleUi.Start();
    }
}