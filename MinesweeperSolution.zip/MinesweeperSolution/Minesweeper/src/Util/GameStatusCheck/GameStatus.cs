﻿public enum GameStatus
{
    Pending,
    Win,
    Lose
}
