﻿namespace Minesweeper.Util.Prompts;

public interface IReader
{
    public string ReadLine(string prompt);
}